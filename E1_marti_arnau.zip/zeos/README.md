TODO:
- Implementar rutina sys_write______________DONE
- Modificar sys_call_table amb nova rutina__DONE
- Crear wrapper per la syscall______________DONE
- Implementar rutina syste_call_handler_____DONE
- Inicialitzar el MSR amb el handler________DONE
- Implementar funció errno i perror_________